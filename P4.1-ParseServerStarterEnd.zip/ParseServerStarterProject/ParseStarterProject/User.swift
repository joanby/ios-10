//
//  User.swift
//  Tinsnappook
//
//  Created by Juan Gabriel Gomila Salas on 27/7/16.
//  Copyright © 2016 Parse. All rights reserved.
//

import UIKit
import CoreLocation

class User: NSObject {
    var objectID : String!
    var name : String!
    var email : String!
    var isFriend : Bool = false
    
    var birthDate : Date?
    var gender : Bool?
    var image: UIImage?
    
    var location : CLLocationCoordinate2D?
    
    init(objectID:String, name:String, email:String) {
        self.objectID = objectID
        self.name = name
        self.email = email
    }
}
