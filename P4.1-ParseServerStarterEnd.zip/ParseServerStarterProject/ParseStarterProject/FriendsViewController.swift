//
//  FriendsViewController.swift
//  Tinsnappook
//
//  Created by Juan Gabriel Gomila Salas on 26/7/16.
//  Copyright © 2016 Parse. All rights reserved.
//

import UIKit
import Parse

class FriendsViewController: UITableViewController {

    @IBOutlet var menuButton: UIBarButtonItem!
    
    var users : [User] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        // Do any additional setup after loading the view.
        
        if self.revealViewController() != nil {
            self.menuButton.target = self.revealViewController()
            self.menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl?.attributedTitle = NSAttributedString(string: "Tira para recargar amigos")
        self.refreshControl?.addTarget(self, action: #selector(FriendsViewController.loadUsers), for: .valueChanged)
        
        
        
        
        //self.createBots()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadUsers()
    }
    
    
    func createBots() {
        let urls = ["Sara":"http://lavidavamagazine.com/wp-content/uploads/2016/04/tecnica-para-seducir-una-mujer.jpg",
                    "Vanesa": "http://imatclinic.com/wp-content/uploads/2015/01/belleza-mujer1.jpg",
                    "Sofía" : "http://www.lavidalucida.com/wp-content/uploads/2015/05/Mujer-pelo-rizos-peinado.jpg",
                    "Mónica" : "http://www.amoramargo.com/wp-content/uploads/2014/12/como-enamorar-a-una-mujer-acuario.jpg",
                    "Antonia" : "https://i.ytimg.com/vi/D00f6q4xwn0/hqdefault.jpg"
        ]
        
        
        for (name, profileURL) in urls {
            let user = PFUser()
            user.username = name + "@bot.com"
            user.email = name + "@bot.com"
            user.password = "bot1234"
            user["gender"] = false
            user["nickname"] = name
            
            let formatter = DateFormatter()
            formatter.dateFormat = "dd-MM-yyyy"
            user["birthdate"] = formatter.date(from: "01-01-1989")
            
            let acl = PFACL()
            acl.getPublicReadAccess = true
            acl.getPublicWriteAccess = true
            user.acl = acl
            
            let url = URL(string: profileURL)
            do {
                let data = try Data(contentsOf: url!)
                user["imageFile"] = PFFile(name: "bot.jpg", data: data)
                user.signUpInBackground(block: { (success, error) in
                    if success {
                        print("Perfil creado correctamente")
                    }
                })
            } catch {
                print("No hemos podido pillar las imagenes")
            }
        }
    }
    
    func loadUsers() {
        self.users = UsersFactory.sharedInstace.getFriends()
        self.refreshControl?.endRefreshing()
        self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.users.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsCell", for: indexPath) as! UserTableViewCell
        
        let user = self.users[indexPath.row]
        
        cell.usernameLabel.text = user.name
        
        if let image = user.image {
            cell.userImageView.image = image
        } else {
            cell.userImageView.image = #imageLiteral(resourceName: "no-friend")
        }
        
        cell.userImageView.layer.cornerRadius = 30
        cell.userImageView.clipsToBounds = true
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /*let cell = tableView.cellForRow(at: indexPath)

        if self.users[indexPath.row].isFriend {
            cell?.accessoryType = .none
            
            self.users[indexPath.row].isFriend = false
            
            let query = PFQuery(className: "UserFriends")
            query.whereKey("idUser", equalTo: (PFUser.current()?.objectId)!)
            query.whereKey("idUserFriend", equalTo: self.users[indexPath.row].objectID)
            
            query.findObjectsInBackground(block: { (objects, error) in
                if error != nil {
                    print(error?.localizedDescription)
                } else {
                    if let objects = objects {
                        for object in objects {
                            object.deleteInBackground()
                        }
                    }
                }
            })
            
        } else {
            cell?.accessoryType = .checkmark
            
            self.users[indexPath.row].isFriend = true

            let friendship = PFObject(className: "UserFriends")
            friendship["idUser"] = PFUser.current()?.objectId
            friendship["idUserFriend"] = self.users[indexPath.row].objectID

            let acl = PFACL()
            acl.getPublicReadAccess = true
            acl.getPublicWriteAccess = true
            
            friendship.acl = acl
            friendship.saveInBackground()
        }*/
    }
    
    
    
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
        if segue.identifier == "showDetail" {
            let destinationVC = segue.destination as! PublicProfileViewController
            destinationVC.user = self.users[(self.tableView.indexPathForSelectedRow?.row)!]
        }
        
     }
 
}
