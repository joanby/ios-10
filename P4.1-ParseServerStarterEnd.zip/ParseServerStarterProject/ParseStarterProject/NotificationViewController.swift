//
//  NotificationViewController.swift
//  Tinsnappook
//
//  Created by Juan Gabriel Gomila Salas on 26/7/16.
//  Copyright © 2016 Parse. All rights reserved.
//

import UIKit
import Parse

class NotificationViewController: UIViewController {

    @IBOutlet var menuButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        if self.revealViewController() != nil {
            self.menuButton.target = self.revealViewController()
            self.menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        self.loadRequests()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadRequests() {
        let query = PFQuery(className: "UserFriends")
        query.whereKey("idUserFriend", equalTo: (PFUser.current()?.objectId)!)

        
        query.findObjectsInBackground(block: { (objects, error) in
            if error != nil {
                print(error?.localizedDescription)
            } else {
                for object in objects! {
                    var found = false
                    for u in UsersFactory.sharedInstace.getFriends() {
                        if u.objectID == object.objectId {
                            found = true
                        }
                    }
                    if !found {
                        let user = UsersFactory.sharedInstace.findUser(idUser: object["idUser"] as! String)
                        print("\(user?.name) te ha enviado solicitud de amistad")
                    }
                }
            }
        })
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */

}
