/**
* Copyright (c) 2015-present, Parse, LLC.
* All rights reserved.
*
* This source code is licensed under the BSD-style license found in the
* LICENSE file in the root directory of this source tree. An additional grant
* of patent rights can be found in the PATENTS file in the same directory.
*/

import UIKit
import Parse


class LoginViewController: UIViewController {

    @IBOutlet var emailTextfield: UITextField!
    
    @IBOutlet var passwordTextfield: UITextField!
    
    var activityIndicator : UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       /*let user = PFObject(className: "Users")
        user["name"] = "Juan"
        user.saveInBackground { (sucess, error) in
            if sucess {
                print("El usuario se ha guardado correctamente en Parse")
            } else {
                if error != nil {
                    print(error?.localizedDescription)
                } else {
                    print("Error desconocido")
                }
            }
        }*/
        
        
        let query = PFQuery(className: "Users")
        query.getObjectInBackground(withId: "hRqMMa7OM2") { (object, error) in
            if error != nil {
                print(error?.localizedDescription)
            } else {
                if let user = object {
                   user["name"] = "Pedro"
                    user.saveInBackground(block: { (success, error) in
                        if success {
                            print("Hemos modificado el usuario")
                        } else {
                            print(error)
                        }
                    })
                }
            }
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if PFUser.current() != nil {
            self.performSegue(withIdentifier: "goToMainVC", sender: nil)
        }
        
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @IBAction func signupPressed(_ sender: UIButton) {
    
        if infoCompleted() {
            //Procedemos a registrar al usuario
            
            self.startActivityIndicator()
            
            let user = PFUser()
            user.username = self.emailTextfield.text
            user.email = self.emailTextfield.text
            user.password = self.passwordTextfield.text
            
            let acl = PFACL()
            acl.getPublicWriteAccess = true
            acl.getPublicReadAccess = true
            user.acl = acl
            
            user.signUpInBackground(block: { (success, error) in
                
                self.stopActivityIndicator()
                
                if error != nil {
                    var errorMessage = "Inténtalo de nuevo, ha habido un error de registro"
                    
                    if let parseError = error?.localizedDescription {
                        errorMessage = parseError
                    }
                    self.createAlert(title: "Error de registro", message: errorMessage)
                    
                } else {
                    print("usuario registrado correctamente")
                    self.performSegue(withIdentifier: "goToMainVC", sender: nil)
                }
            })
            
        }
        
        
    }
   
    @IBAction func loginPressed(_ sender: UIButton) {
        
        if infoCompleted() {
            //Procedemos a logear al usuario
            self.startActivityIndicator()
            
            PFUser.logInWithUsername(inBackground: self.emailTextfield.text!, password: self.passwordTextfield.text!, block: { (user, error) in
                
                self.stopActivityIndicator()
                
                if error != nil {
                    var errorMessage = "Inténtalo de nuevo, ha habido un error de login"
                    
                    if let parseError = error?.localizedDescription {
                        errorMessage = parseError
                    }
                    self.createAlert(title: "Error de login", message: errorMessage)
                } else {
                    print("Hemos entrado correctamente")
                    self.performSegue(withIdentifier: "goToMainVC", sender: nil)

                }
            })
            
        }
    
    }
    @IBAction func recoverPassword(_ sender: UIButton) {

        let alertController = UIAlertController(title: "Recuperar contraseña", message: "Introduce el email de registro en Tinsnappook", preferredStyle: .alert)
        
        alertController.addTextField { (textfield) in
            textfield.placeholder = "Introduce aquí tu email"
        }
        
        let okAction = UIAlertAction(title: "Recuperar contraseña", style: .default) { (action) in
            let theEmailTextfield = alertController.textFields![0] as UITextField
            
            PFUser.requestPasswordResetForEmail(inBackground: theEmailTextfield.text!, block: { (success, error) in
                if error != nil {
                    var errorMessage = "Inténtalo de nuevo, ha habido un error al recuperar la contraseña"
                    
                    if let parseError = error?.localizedDescription {
                        errorMessage = parseError
                    }
                    self.createAlert(title: "Error de contraseña", message: errorMessage)
                } else {
                    self.createAlert(title: "Contraseña recuperada", message: "Mira tu bandeja de entrada de \(theEmailTextfield.text!) y sigue las instrucciones indicadas")
                }
            })
            
        }
        
        let cancelAction = UIAlertAction(title: "Ahora no", style: .cancel, handler: nil)
    
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    func infoCompleted() -> Bool {
        var infoCompleted = true
        
        if self.emailTextfield.text == "" || self.passwordTextfield.text == "" {
            infoCompleted = false
            
            self.createAlert(title: "Verifica tus datos", message: "Asegúrate de introducir un correo y una contraseña válidos")
            
        }
        
        return infoCompleted
    }
    
    
    func createAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title , message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func startActivityIndicator()  {
        self.activityIndicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        self.activityIndicator.center = self.view.center
        self.activityIndicator.hidesWhenStopped = true
        self.activityIndicator.activityIndicatorViewStyle = .gray
        self.view.addSubview(self.activityIndicator)
        self.activityIndicator.startAnimating()
        UIApplication.shared.beginIgnoringInteractionEvents()
    }
    
    
    func stopActivityIndicator(){
        self.activityIndicator.stopAnimating()
        UIApplication.shared.endIgnoringInteractionEvents()
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
