//
//  UsersFactory.swift
//  Tinsnappook
//
//  Created by Juan Gabriel Gomila Salas on 28/7/16.
//  Copyright © 2016 Parse. All rights reserved.
//

import UIKit
import Parse

class UsersFactory: NSObject {
    static let sharedInstace = UsersFactory()
    static let notificationName = Notification.Name("UsersLoaded")
    
    var currentUser : User?
    
    var users : [User] = []
    
    override init() {
        super.init()
        self.loadMainUser()
        self.loadUsers()
    }
    
    
    func getFriends() -> [User]{

        var friends :[User] = []
        for user in self.users {
            if user.isFriend {
                friends.append(user)
            }
        }
        return friends
    }
    
    func getUnknownPeople() -> [User]{

        var nofriends :[User] = []
        for user in self.users {
            if !user.isFriend {
                nofriends.append(user)
            }
        }
        return nofriends
    }
    
    func getUsers() -> [User]{
        return self.users
    }
    
    func loadMainUser() {
        let pfUser = PFUser.current()!
        let objectID = pfUser.objectId!
        let defaultUserName = pfUser.username?.components(separatedBy: "@")[0]
        let customUserName = pfUser["nickname"] as? String
        let email = pfUser.email
        
        self.currentUser = User(objectID: objectID, name: ((customUserName == nil) ? defaultUserName : customUserName)!, email: email!)
        
        if let gender = pfUser["gender"] as? Bool {
            self.currentUser!.gender = gender
        }
        
        if let birthDate = pfUser["birthdate"] as? Date {
            self.currentUser!.birthDate = birthDate
        }
        
        if let imageFile = pfUser["imageFile"] as? PFFile {
            imageFile.getDataInBackground { (data, error) in
                if let data = data {
                    self.currentUser!.image = UIImage(data: data)
                }
            }
        }
        
        if let geopoint = pfUser["geopoint"] as? PFGeoPoint {
            self.currentUser!.location = CLLocationCoordinate2DMake(geopoint.latitude, geopoint.longitude)
        }
        
        
        PFGeoPoint.geoPointForCurrentLocation { (geopoint, error) in
            if let geopoint = geopoint {
                
                self.currentUser!.location = CLLocationCoordinate2DMake(geopoint.latitude, geopoint.longitude)
                
                PFUser.current()?["geopoint"] = geopoint
                PFUser.current()?.saveInBackground()
                
            }
        }
        
    }
    
    func loadUsers() {
        let query = PFUser.query()
        query?.whereKey("objectId", notEqualTo: (PFUser.current()?.objectId)!)
        
        let geopoint = PFGeoPoint(latitude: (self.currentUser?.location?.latitude)!, longitude: (self.currentUser?.location?.longitude)!)

        query?.whereKey("geopoint", withinGeoBoxFromSouthwest: PFGeoPoint(latitude:(geopoint.latitude)-1, longitude: (geopoint.longitude)-1), toNortheast: PFGeoPoint(latitude: (geopoint.latitude)+1, longitude: (geopoint.longitude)+1))
        
        query?.findObjectsInBackground(block: { (objects, error) in
            if error != nil {
                print(error?.localizedDescription)
            } else {
                self.users.removeAll()
                
                for object in objects! {
                    if let user = object as? PFUser {
                        
                        if user.objectId != PFUser.current()?.objectId {
                            
                            let email = user.email!

                            let defaultUserName = user.username?.components(separatedBy: "@")[0].capitalized
                            let customUserName = user["nickname"] as? String

                            
                            
                            let objectID = user.objectId!
                            
                            let myUser = User(objectID: objectID, name: ((customUserName != nil) ? customUserName : defaultUserName)!, email: email)
                            
                            if let geopoint = user["geopoint"] as? PFGeoPoint {
                                let location = CLLocationCoordinate2DMake(geopoint.latitude, geopoint.longitude)
                                myUser.location = location
                            }
                            
                            if let gender = user["gender"] as? Bool {
                                myUser.gender = gender
                            }
                            
                            if let birthdate = user["birthdate"] as? Date {
                                myUser.birthDate = birthdate
                            }
                            
                            if let imageFile = user["imageFile"] as? PFFile {
                                imageFile.getDataInBackground { (data, error) in
                                    if let data = data {
                                        myUser.image = UIImage(data: data)
                                    }
                                }
                            }
                            
                            
                            let query = PFQuery(className: "UserFriends")
                            query.whereKey("idUser", equalTo: (PFUser.current()?.objectId)!)
                            query.whereKey("idUserFriend", equalTo: myUser.objectID)
                            
                            query.findObjectsInBackground(block: { (objects, error) in
                                if error != nil {
                                    print(error?.localizedDescription)
                                } else {
                                    if let objects = objects {
                                        
                                        if objects.count > 0 {
                                            myUser.isFriend = true
                                        }                                    }
                                }
                            })
                            
                            
                            self.users.append(myUser)
                        }
                        
                    }
                }
                

                NotificationCenter.default.post(name: UsersFactory.notificationName, object: nil)
                
                
            }
        })
    }
    
    
    func findUser(idUser : String) -> User? {
        
        for user in self.users{
            if user.objectID == idUser {
                return user
            }
        }
        
        return nil
    }
    
    func findUserAt(index: Int) -> User? {
        if index>=0 && index < self.users.count {
            return self.users[index]
        }
        
        return nil
    }
    
    
    
}
