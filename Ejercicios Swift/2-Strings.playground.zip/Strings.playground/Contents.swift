var name : String = "Juan Gabriel Gomila Salas"

name.uppercased()

name.lowercased()


var idUser = ""

idUser = "74625385027462"


var 🐷 = " Me ❤️ los 🐷🐷🐷🐷🐷🐷🐷🐷"

🐷

var 🏖 = "playa"


🏖


var 💃🏻 = "Olé!"