
var shoppingList : [String : String] = ["Patatas":"Tengo que comprar 1 kg de patatas",
                                         "Huevos":"Necesito 5 huevos para la tortilla",
                                       "Cebollas":"Necesito 3 cebollas grandes",
                                      "Pimientos":"Los pimientos verdes enriquecen la tortilla"]


var luckyNumbers :[String: Int] = ["1":7, "2":5, "3":13]


var myDict : [Int:Float] = [:]

myDict[3] = 5.4

print(myDict)


shoppingList["Huevos"]

luckyNumbers["1"]

shoppingList.count
luckyNumbers.count

shoppingList["Huevos"] = "Necesito 6 huevos para una buena tortilla"

print(shoppingList)

shoppingList["Platanos"] = "Necesito 3 plátanos para una buena macedonia"

print(shoppingList)

shoppingList["Manzanas"] = "Necesitaremos 2 manzanas golden para la macedonia"

print(shoppingList)




var numbers : [Int: String] = [1:"Uno", 2 : "Dos", 3 : "Tres", 4 : "Cuatro"]

numbers[3]

if numbers.isEmpty {
    print("Este diccionario está vacío")
} else {
    print("El diccionario tiene \(numbers.count) elementos")
}


if let myNumber = numbers[3] {
    print(myNumber)
} else {
    print("El valor no ha podido ser recuperado")
}







var airports = [String: String]() // [String:String] = []

airports =  ["PMI":"Palma de Mallorca", "BCN": "Barcelona", "MAD": "Madrid", "VAL":"Valenca"]

if let oldAirport = airports.updateValue("Valencia", forKey: "VAL"){
    print("El aeropuerto antiguo para la clave VAL era \(oldAirport)")
}

print(airports["VAL"])


airports["VAL"] = nil

if let oldAirport = airports.removeValueForKey("VAL") {
    print("Hemos eliminado el aeropuerto de \(oldAirport)")
}



print(airports["VAL"])




