let name = "Juan Gabriel"
let age = 28

let 🐷 = "🐷💃🏻"

let presentation = "Hola, me llamo \(name) y tengo \(age) años. \(🐷)"