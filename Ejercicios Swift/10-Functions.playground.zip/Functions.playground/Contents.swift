import Foundation


func sayHello(time: Int, to: String) -> Void {
    //Esto es el cuerpo de la función
    let date = Date()
    print("hola \(to), ahora son: \(date)")
    print("hemos dicho hola \(time) veces")
}


sayHello(time: 1, to: "Pepe")

sayHello(time: 2, to: "Antonia")

sayHello(time: 3, to: "María")



func power2(exponent : Int ) -> Int {
    return Int(pow(2,exponent))
}

let exponent = 10
let power = power2(exponent: exponent)
print("El valor de 2 elevado a \(exponent) es \(power)")



var extras = ["Salchichas"  : 0.25,
              "Cebolla"     : 0.10,
              "Atún"        : 0.35,
              "Jalapeños"   : 0.10,
              "Queso azul"  : 0.60,
              "Pepperoni"   : 0.17
]


func addExtraIngredient(extras: [String : Double], ingredientName : String, quantity : Int) -> Double? {
    /*if let unitPrice = extras[ingredientName] {
        return Double(quantity) * unitPrice
    }

    return nil*/
    
    guard let unitPrice = extras[ingredientName] else {
        return nil
    }
    return Double(quantity) * unitPrice
}


addExtraIngredient(extras: extras, ingredientName: "Cebolla", quantity: 5)
addExtraIngredient(extras: extras, ingredientName: "Ketchup", quantity: 2)



let company = ("AAPL", "Apple Inc", 95.89)

company.0
company.1
company.2



let (stockCode, companyName, stockPrice) = ("AAPL", "Apple Inc", 95.89)

print("El valor en bolsa de \(companyName) es \(stockPrice)")




let stocksCompany = (id: "AAPL", name: "Apple Inc", price: 95.89)

stocksCompany.name



func getProduct(idProduct: Int) -> (id: String, name: String, price: Double, isAvailable : Bool) {
    var id = "IPH0", name = "iPhone 5", price = 599.99, isAvailable = true
    switch idProduct {
    case 1:
        id = "IPH6"
        name = "iPhone 6"
        price = 699.99
        
    case 2:
        id = "IPDA"
        name = "iPad Air"
        price = 499.90
        isAvailable = false
    case 3:
        id = "IMC2"
        name = "iMac 2016"
        price = 1399
    default:
        break
    }
    
    return (id, name, price, isAvailable)
    
}


let product = getProduct(idProduct: -8)

print("El producto con el id \(product.id) se llama \(product.name) y cuesta \(product.price) €")

if product.isAvailable {
    print("Está disponible en stock")
} else {
    print("No lo tenemos disponible, pero lo podemos pedir")
}





