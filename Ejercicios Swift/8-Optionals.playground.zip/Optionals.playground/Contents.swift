var str : String
str = "Hola"
print(str)


var strO : String?
print(strO)
strO = "Soy un string opcional"
print(strO)
strO = nil
print(strO)

strO = "Hola"
if let strO = strO {
    print(strO)
}

var strR : String!
strR = "Soy requerida"
print(strR)
strR = nil


let myConst : String! = ""
print(myConst)


var dict = [3:"Tres"]

print(dict[6]) //nil <-> null




let airports = ["PMI":"Palma de Mallorca", "BCN":"Barcelona", "MAD": "Madrid", "VAL":"Valencia"]

if let theAirport = airports["VAP"] {

    print("El aeropuerto existe")
}