for var i in (0..<10).reversed() {
    print("\(i) elevado a 2 = \(i*i)")
    
    if  i == 4 {
        break
    }
}

//print("He llegado hasta el número \(i)")

print("==============================")

var i = 0

var found = false


while !found {
    //print("\(i) elevado a 2 = \(i*i)")
    i = i+1
    
    if  i % 5 == 0 && i % 7 == 0 && i > 7 {
        found = true
        print("\(i) es múltiplo de 7")
    }
}


print("El último número al que he llegado ha sido \(i)")


print("==============================")


var names = ["Sabio", "Gruñón", "Mocoso", "Tímido", "Mudito", "Dormilón", "Feliz"]

for i in 0..<names.count {
    print("El enanito número \(i) se llama \(names[i])")
}

for dwarfName in names {
    print("\(dwarfName)")
}


for (index, dwarfName) in names.enumerated() {
    print("El enano en la posición \(index) se llama \(dwarfName)")
}



var pos = 0

while pos < names.count {
    print("El objecto en la posición \(pos) vale \(names[pos])")
    pos += 1
}


print("==============================")


var extras = ["Salchichas"  : 0.25,
              "Cebolla"     : 0.10,
              "Atún"        : 0.35,
              "Jalapeños"   : 0.10,
              "Queso azul"  : 0.60,
              "Pepperoni"   : 0.17
]

extras["Rúcula"] = 0.12

print(extras)


for (key, value) in extras {
    print("El valor de añadir \(key) es de \(value) € ")
}

for key in extras.keys {
    print("El ingrediente que puedes añadir es \(key) y este cuesta \(extras[key]!)")
    extras[key] = extras[key]! * 1.10
}

for value in extras.values {
    print("El ingrediente vale \(value)")
    //value = value * 1.10
}









