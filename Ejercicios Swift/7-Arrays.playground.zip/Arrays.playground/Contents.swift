var age : Int = 28

var name : String = "Juan Gabriel"



var shoppingList : [String] = ["Patatas", "Huevos", "Cebolla", "Pimientos"]

var luckyNumbers : [Int] = [7, 5, 13]

let weights : [Double] = [68.9, 49.5, 80.0]

let activeItems : [Bool] = [true, false, false, true, true]

var newArray : [String] = []


shoppingList.count

shoppingList.append("Plátanos")

shoppingList.count

shoppingList.append("5 litronas")

shoppingList.count

luckyNumbers.append(3)

luckyNumbers.count


print(shoppingList)

print(shoppingList.first)

print(shoppingList.last)

shoppingList[0]

shoppingList[1]

shoppingList[3]

shoppingList[shoppingList.count-1]

shoppingList[5] = "2 litronas"

print(shoppingList)


shoppingList.insert("Brócoli", at: 2)

print(shoppingList)

shoppingList.remove(at: 3)

print(shoppingList)

shoppingList.index(of: "Patata")

if shoppingList.contains("Pimientos"){
    let index = shoppingList.index(of: "Pimientos")
    shoppingList.remove(at: index!)
}
print(shoppingList)




shoppingList += ["Chuletas", "Lechuga", "Salmón"]

shoppingList[2...4]











