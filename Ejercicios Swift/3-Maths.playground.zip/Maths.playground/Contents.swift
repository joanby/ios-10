import Foundation

var pi = 3.14159265

Int(pi)

floor(pi)

ceil(pi)

sqrt(4.0)

pow(2, 256)

var wallet = 50

wallet -= 7

wallet -= 8

wallet -= 10

wallet -= 5

wallet -= 10

wallet -= 5

wallet -= 5