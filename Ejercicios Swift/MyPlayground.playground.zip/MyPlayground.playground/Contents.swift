import UIKit

//Larga vida a ++ y --

var age = 28

age -= 1

//Bucles con ++ y --

for _ in 0..<9 {
    print("Hola")
}

//Parametros

func addTwoNumbers(x:Int, y:Int) -> Int {
    return x+y
}

addTwoNumbers(x: 3, y: 2)

//Enums

enum Direction {
    case north
    case south
    case east
    case west
}

Direction.west


//Acortar nombres


var food = ["Pizza", "Macarrones", "Fajitas"]

food.append("Café")
food.insert("Ensalada", at: 2)


let red = UIColor.red()

let newColor = #colorLiteral(red: 0.6637836695, green: 0.4033902586, blue: 0.08084951341, alpha: 1)












