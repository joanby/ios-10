let mark = "A"


/*if mark == "A" {
    print("Genial! Eres un crack!")
}

if mark == "B" {
    print("Enhorabuena, es una gran nota.")
}

if mark == "C" {
    print("Buen trabajo, has aprobado")
}

if mark == "D" {
    print("Te ha faltado poco")
}


if mark == "F" {
    print("Tendrás que estudiar más para la próxima")
}*/


switch mark {
    case "A":
        print("Genial! Eres un crack!")
    case "B":
        print("Enhorabuena, es una gran nota.")
    case "C":
        print("Buen trabajo, has aprobado")
    case "D":
        print("Te ha faltado poco")
    case "F":
        print("Tendrás que estudiar más para la próxima")
    default:
        print("La nota no es válida")
}



let isWoman = true

switch isWoman {
    case true:
        print("Soy una mujer")
    case false:
        print("Soy un hombre")
}




let character = "u"

switch character {
case "a", "e", "i", "o", "u":
    print("Es una vocal")
default:
    print("No es una vocal")
}



let speed = 130

switch speed {
case 0...60:
    print("Vamos demasiado despacio para ir por autopista")
case 61...100:
    print("Velocidad de crucero")
case 101...120:
    print("Velocidad considerable, hay que estar alerta")
case 121...220:
    print("Te has pasado de límite de velocidad. Te va a caer una multa")
default:
    print("Velocidad no válida")
}








