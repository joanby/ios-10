var str: String = "Hola Playground"

str = "Hola mundo"

var age: Int = 28

age

age = 5

age

age = 32

age = 28

var name : String = "Juan Gabriel"


str = "Hola \(name), tengo \(age) años"


var nickname : String = "JB"

let birthDate : Int = 1988

let pi : Float = 3.14159265

str

pi

age

name

var hola = "👋🏽"

hola


var tiempoQueHaceEnMallorcaHoy : String

tiempoQueHaceEnMallorcaHoy = "Nuboso"

let gravity : Float = 9.81