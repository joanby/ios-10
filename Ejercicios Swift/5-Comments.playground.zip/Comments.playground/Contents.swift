
//Esta variable guarda la edad del usuario
let age = 28

/*
 Esta variable guarda el nombre del usuario
 Este tipo de variable es un String y puede 
    ser tan largo como queramos
*/
let name = "Juan Gabriel"

//Altura del usuario
let height = 1.65

/*Esta es la cartera del usuario. 
 Inicialmente toma el valor de 100€ para poder gastarlos durante el día*/
var wallet = 100

//Variable booleana que registra si es día de paga
let isPayDay = true

/*
 En caso de ser día de paga, nos toca ganar 300 euros y meterlos
 directamente en nuestra cartera para usarlos a posteriori 💰💰💰💰
 */
if isPayDay {
    wallet += 300
}

//Nos gastamos 10 € de la cartera en tomar un heladito 🍦
wallet -= 10

//Rellenamos el depósito de gasolina para poder seguir trabajando 🚗
wallet -= 50

/*Para poder subir a la atracción, el usuario debe ser o bien amyor de edad
 o bien superar el metro y medio de altura.*/
if age >= 18 || height > 1.5 {
    print("Puedes montarte en la atracción")
}
// TODO: hay que implementar el caso de la gente que no se pueda montar en la atracción


print(age)

print("Hola me llamo \(name)")

print("hola", "me", "llamo", name, separator: "-", terminator: ".")



