//NS : Next Step 
import Foundation

import UIKit

let date : Date = Date()

let dateFormatter : DateFormatter

let timer : Timer

let url : NSURL

let string : NSString
