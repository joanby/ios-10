let isPayDay : Bool = true

var wallet = 20


if isPayDay {
    wallet += 300
    wallet += 250
    wallet += 50
}

wallet += 20

wallet



let isWoman = false

if isWoman {
    print("Soy una mujer")
}



let x = 12
let y = 18

if x >= y {
    if x == y {
        print("x es igual que y")
    }
    if x != y{
        print("x es mayor que y")
    }
}

if x < y {
    print("x es menor que y")
}



let name = "Juan Gabriel"

if name != "Juan Gabriel" {
    wallet += 100
}

wallet




let age = 28

let height = 1.65

var canRide = false

if age >= 18 || height > 1.5 {
    canRide = true
}


if canRide {
    print("puedes subir a la atracción")
} else {
    print("no puedes subir a la atracción")
}








